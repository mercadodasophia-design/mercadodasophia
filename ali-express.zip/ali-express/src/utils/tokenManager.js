import fs from "fs";
import { request } from "undici";
import dotenv from "dotenv";

dotenv.config({ path: '../../config.env' });

const TOKEN_FILE = "./data/tokens.json";
const { APP_KEY, APP_SECRET } = process.env;

export const saveTokens = (tokens) => {
  fs.writeFileSync(TOKEN_FILE, JSON.stringify({ ...tokens, updated_at: Date.now() }, null, 2));
};

export const loadTokens = () => {
  if (!fs.existsSync(TOKEN_FILE)) return null;
  return JSON.parse(fs.readFileSync(TOKEN_FILE));
};

export const refreshTokenIfNeeded = async () => {
  const tokens = loadTokens();
  if (!tokens) throw new Error("Tokens não encontrados. Faça login primeiro.");

  const expiresIn = tokens.expires_in * 1000;
  const expired = Date.now() - tokens.updated_at > expiresIn - 60000;

  if (!expired) return tokens;

  console.log("🔄 Renovando token...");
  const url = `https://api-sg.aliexpress.com/oauth/token`;
  const params = new URLSearchParams({
    grant_type: "refresh_token",
    client_id: APP_KEY,
    client_secret: APP_SECRET,
    refresh_token: tokens.refresh_token,
  });

  const { body } = await request(url, {
    method: 'POST',
    body: params.toString(),
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  });
  
  const data = await body.json();
  saveTokens(data);
  return data;
};
