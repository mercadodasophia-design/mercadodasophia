import { request } from "undici";
import dotenv from "dotenv";
import { saveTokens, loadTokens, refreshTokenIfNeeded } from "../utils/tokenManager.js";

dotenv.config({ path: '../../config.env' });

const BASE_URL = "https://api-sg.aliexpress.com";
const OAUTH_URL = "https://auth.aliexpress.com";
const { APP_KEY, APP_SECRET, REDIRECT_URI } = process.env;

// Valores padrão para desenvolvimento
const DEFAULT_APP_KEY = "517616";
const DEFAULT_APP_SECRET = "TTqNmTMs5Q0QiPbulDNenhXr2My18nN4";
const DEFAULT_REDIRECT_URI = "https://mercadodasophia-api.onrender.com/api/aliexpress/oauth-callback";

// Usar valores das variáveis de ambiente ou padrões
const FINAL_APP_KEY = APP_KEY || DEFAULT_APP_KEY;
const FINAL_APP_SECRET = APP_SECRET || DEFAULT_APP_SECRET;
const FINAL_REDIRECT_URI = REDIRECT_URI || DEFAULT_REDIRECT_URI;

// Debug: verificar se as variáveis estão carregadas
console.log('🔧 Configurações carregadas:', {
  APP_KEY: FINAL_APP_KEY ? '✅ Configurado' : '❌ Não configurado',
  APP_SECRET: FINAL_APP_SECRET ? '✅ Configurado' : '❌ Não configurado',
  REDIRECT_URI: FINAL_REDIRECT_URI ? '✅ Configurado' : '❌ Não configurado'
});

export const getAuthUrl = () => {
  return `${OAUTH_URL}/oauth/authorize?response_type=code&client_id=${FINAL_APP_KEY}&redirect_uri=${encodeURIComponent(FINAL_REDIRECT_URI)}`;
};

export const handleCallback = async (code) => {
  // URL correta do AliExpress conforme documentação
  const url = `${BASE_URL}/auth/token/create`;
  
  const params = new URLSearchParams({
    code,
    uuid: 'mercadodasophia_uuid' // UUID opcional conforme documentação
  });

  console.log('🔄 Fazendo requisição para:', url);
  console.log('📊 Parâmetros:', Object.fromEntries(params));

  try {
    const { body, statusCode } = await request(url, {
      method: 'POST',
      body: params.toString(),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
        'User-Agent': 'MercadoDaSophia/1.0'
      }
    });
    
    console.log('📡 Status da resposta:', statusCode);
    
    if (statusCode === 200) {
      const data = await body.json();
      console.log('✅ Resposta processada:', data);
      
      if (data.error || data.code !== '0') {
        throw new Error(`Erro do AliExpress: ${data.message || data.error || 'Erro desconhecido'}`);
      }
      
      saveTokens(data);
      return data;
    } else {
      const errorText = await body.text();
      console.log('❌ Erro na resposta:', errorText);
      throw new Error(`Erro ${statusCode}: ${errorText}`);
    }
  } catch (error) {
    console.log('❌ Erro na requisição:', error);
    throw error;
  }
};

export const searchProducts = async (keyword) => {
  const tokens = await refreshTokenIfNeeded();
  const timestamp = Date.now();

  const params = new URLSearchParams({
    method: "aliexpress.ds.product.get",
    app_key: FINAL_APP_KEY,
    timestamp,
    session: tokens.access_token,
    sign_method: "md5",
    format: "json",
    v: "2.0",
    keywords: keyword,
    page_size: 10,
  });

  const { body } = await request(`${BASE_URL}/router/rest?${params.toString()}`, {
    method: 'GET'
  });

  return await body.json();
};
