import express from "express";
import { getAuthUrl, handleCallback, searchProducts } from "../api/aliexpress.js";

const router = express.Router();

router.get("/auth", (req, res) => {
  res.json({ url: getAuthUrl() });
});

router.get("/oauth-callback", async (req, res) => {
  const code = req.query.code;
  console.log('🔐 OAuth Callback recebido:', { code });
  
  if (!code) {
    console.log('❌ Código de autorização não encontrado');
    return res.status(400).json({ 
      error: "Código de autorização não encontrado",
      success: false 
    });
  }

  try {
    console.log('🔄 Processando código de autorização...');
    const result = await handleCallback(code);
    console.log('✅ Tokens processados com sucesso:', result);
    
    res.json({ 
      success: true,
      message: "Autorização concluída! Tokens salvos com sucesso.",
      data: result
    });
  } catch (err) {
    console.log('❌ Erro no callback:', err);
    res.status(500).json({ 
      error: err.message,
      success: false,
      details: err.toString()
    });
  }
});

router.get("/products", async (req, res) => {
  const keyword = req.query.q || "electronics";
  try {
    const products = await searchProducts(keyword);
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
