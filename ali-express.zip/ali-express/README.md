# API AliExpress Dropshipping

API Node.js para integração com AliExpress usando OAuth2.

## Configuração

1. **Instalar dependências**:
   ```bash
   npm install
   ```

2. **Configurar credenciais**:
   - Renomeie `config.env.example` para `config.env`
   - Adicione suas credenciais do AliExpress:
   ```
   APP_KEY=sua_app_key_aqui
   APP_SECRET=sua_app_secret_aqui
   REDIRECT_URI=https://seu-dominio.com/api/aliexpress/oauth-callback
   ```

3. **Executar**:
   ```bash
   npm start
   ```

## Endpoints

- `GET /api/aliexpress/auth` - URL de autorização OAuth2
- `GET /api/aliexpress/oauth-callback` - Callback OAuth2
- `GET /api/aliexpress/products?q=keyword` - Buscar produtos

## Fluxo OAuth2

1. Acesse `/api/aliexpress/auth` para obter URL de autorização
2. Faça login no AliExpress e autorize
3. O callback salvará os tokens automaticamente
4. Use `/api/aliexpress/products` para buscar produtos
